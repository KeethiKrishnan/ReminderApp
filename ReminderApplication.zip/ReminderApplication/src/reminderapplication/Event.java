
package reminderapplication;

public class Event {
    private int id;
    private String event;
    private String date;
    
    public Event(int ID, String EVENT, String DATE) {
        this.id =ID;
        this.event= EVENT;
        this.date =DATE;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
}
